
Step 1: Run the following command in the command prompt:
pip install -r requirements.txt

Step 2: Open the movie-review-using-flask app with VS Code.

Step 3:

1.Open the Anaconda command prompt.
2.Navigate to the directory of the movie-review-using-flask app:
cd <path  movie-review-using-flask>
3. Run the flask app: python python .\01_Movie-Review-App.py

Step 4: copy the IP address with port number , copy paste in web browser
 Enter the input Text -Movie Review  and then click Predict button.
===============================================================================